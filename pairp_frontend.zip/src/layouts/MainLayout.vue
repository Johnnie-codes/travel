<script setup>
import Button from "@/components/Button.vue";
import navs from "@/config/navs";
import { RouterLink } from "vue-router";

const grouped = Object.groupBy(navs, (el) => el.type);
</script>

<template>
  <div class="flex h-full w-full">
    <div class="__drawer w-drawer-width">
      <div class="p-4 h-20 flex gap-4 items-center justify-center">
        <img src="@/assets/lion.svg" />
        <span class="font-bold text-base-clr text-lg">LION INSURANCE</span>
      </div>
      <div
        class="show-scrollbar flex flex-col justify-start !p-2 !px-6 gap-1 h-[calc(100%-5rem)]"
      >
        <template :key="name" v-for="(navs, name) in grouped">
          <div class="px-4" v-if="name">
            <p class="border-t border-base-clr1 text-xs text-base-clr pt-4">
              {{ name }}
            </p>
          </div>
          <RouterLink
            :key="nav.name"
            v-for="nav in navs"
            class="flex rounded transition-all duration-200 ease-linear hover:bg-gray-200"
            :to="nav.path"
          >
            <Button
              class="!h-12 flex-1 max-w-full flex items-center pl-5 gap-3"
            >
              <div class="grid place-items-center rounded">
                <IIcon :style="{ fontSize: '18px' }" :icon="nav.icon" />
              </div>
              <span>{{ nav.name }}</span>
            </Button>
          </RouterLink>
        </template>
      </div>
    </div>
    <div class="flex flex-col w-[calc(100%-var(--drawer-width))]">
      <div class="h-navbar-height flex items-center jub gap-4 px-5">
        <p class="font-bold">Overview</p>
      </div>
      <div
        class="h-[calc(100%-var(--navbar-height))] bg-base-clr2 w-full px-5 pt-5"
      >
        <RouterView />
      </div>
    </div>
  </div>
</template>

<style scoped>
.__drawer .router-link-exact-active {
  background-color: theme("colors.primary");
  color: rgb(var(--base-clr2));
}
</style>
