import "./assets/wind.css";
import { Icon } from "@iconify/vue";
import { createApp } from "vue";
import { createPinia } from "pinia";
import vRipple from "@/directives/vRipple";
import App from "./App.vue";
import router from "./router";
import toast from "./toast";

const app = createApp(App);

app.use(createPinia());
app.use(router);
app.use(toast);
app.component("IIcon", Icon);
app.directive("ripple", vRipple);
app.mount("#app");
