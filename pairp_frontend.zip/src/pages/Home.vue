<template>
	<p class="text-primary">asd</p>
</template>