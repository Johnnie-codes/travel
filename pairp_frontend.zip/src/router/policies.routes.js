import PolicyIndex from "@/features/policies/pages/index.vue";
import Policies from "@/features/policies/pages/Policies.vue";
import Providers from "@/features/providers/pages/providers.vue";
import ProviderIndex from "@/features/providers/pages/index.vue";
import ClaimIndex from "@/features/claims/pages/index.vue";
import Claims from "@/features/claims/pages/claims.vue";

export default [
  {
    path: "/policies",
    name: "PoliciesIndex",
    component: PolicyIndex,
    children: [
      {
        path: "",
        name: "Policy",
        component: Policies,
      },
    ],
  },
  {
    path: "/providers",
    name: "providerIndex",
    component: ProviderIndex,
    children: [
      {
        path: "",
        name: "Provider",
        component: Providers,
      },
    ],
  },
  {
    path: "/claims",
    name: "ClaimIndex",
    component: ClaimIndex,
    children: [
      {
        path: "",
        name: "Claims",
        component: Claims,
      },
    ],
  },
];
