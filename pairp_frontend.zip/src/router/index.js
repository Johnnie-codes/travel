import { createRouter, createWebHistory } from "vue-router";
import HomeView from "@/pages/Home.vue";
import MainLayout from "@/layouts/MainLayout.vue";
import Index from "@/features/policies/pages/index.vue";
import Policies from "@/features/policies/pages/Policies.vue";
import policiesRoutes from "./policies.routes";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      component: MainLayout,
      children: [
        {
          path: "",
          name: "home",
          component: HomeView,
        },

        ...policiesRoutes,
      ],
    },
  ],
});

export default router;
