<script setup>
import SubTitle from "@/components/SubTitle.vue";
import Table from "@/components/Table.vue";
import TableRowSkeleton from "@/components/TableRowSkeleton.vue";
import { ref } from "vue";
const entries = ref([
  {
    fullName: "Abebe beso bela",
    date: "05-08-2024",
    contactPerson: "Mohammed Kedir",
    phoneNumber: "945343243",
    status: "Active",
  },
  {
    fullName: "Abebe beso bela",
    date: "05-08-2024",
    contactPerson: "Mohammed Kedir",
    phoneNumber: "945343243",
    status: "Active",
  },
  {
    fullName: "Abebe beso bela",
    date: "05-08-2024",
    contactPerson: "Mohammed Kedir",
    phoneNumber: "945343243",
    status: "Active",
  },
  {
    fullName: "Abebe beso bela",
    date: "05-08-2024",
    contactPerson: "Mohammed Kedir",
    phoneNumber: "945343243",
    status: "Active",
  },
]);
// import Title from "@/components/title.vue";
</script>
<template>
  <div class="flex flex-col gap-5">
    <SubTitle title="4 providers">
      <template #header>
        <div class="bg-primary text-white p-2 rounded-md">Add New Provider</div>
      </template>
    </SubTitle>
    <div class="flex flex-col gap-4">
      <Table
        :headers="{
          head: [
            'Provider Full Name',
            'Registered',
            'Contact Person',
            'Contact Person Number',
            'Status',
          ],
          row: ['fullName', 'date', 'contactPerson', 'phoneNumber', 'status'],
        }"
        :rows="entries"
        :Fallback="TableRowSkeleton"
      >
        <template #actions="{ row }">
          <Button
            v-if="row.quantity > 0"
            @click.stop="addMed(row)"
            class="text-sm"
            size="xs"
            :type="row.quantity > 0 ? 'secondary' : 'primary'"
          >
            Add
          </Button>
        </template>
      </Table>
    </div>
  </div>
</template>
