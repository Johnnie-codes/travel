<script setup></script>
<template>
  <RouterView />
</template>
